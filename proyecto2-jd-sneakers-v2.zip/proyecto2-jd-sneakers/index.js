const sneakersArray = [
  {
    id: '001',
    brand: 'Nike',
    model: 'Air Max 1',
    price: '120.00€',
    color: 'White',
    gender: 'man',
    image: 'assets/nk-airmax1.png',
    offert: 'no'
  },
  {
    id: '002',
    brand: 'New Balance',
    model: '9060 Grey',
    price: '80.00€',
    color: 'Grey',
    gender: 'man',
    image: 'assets/nb-9060-grey.png',
    offert: 'no'
  },
  {
    id: '003',
    brand: 'Nike',
    model: 'Revolution',
    price: '90.00€',
    color: 'Blue',
    gender: 'man',
    image: 'assets/nk-revolution.png',
    offert: 'no'
  },
  {
    id: '004',
    brand: 'Adidas',
    model: 'Forum Buckle',
    price: '100.00€',
    color: 'Blue',
    gender: 'man',
    image: 'assets/ad-forumbuckle.png',
    offert: 'no'
  },
  {
    id: '005',
    brand: 'Adidas',
    model: 'Campus',
    price: '120.00€',
    color: 'Green',
    gender: 'man',
    image: 'assets/ad-campus.png',
    offert: 'no'
  },
  {
    id: '006',
    brand: 'New Balance',
    model: '327',
    price: '120.00€',
    color: 'White',
    gender: 'man',
    image: 'assets/nb-327.png',
    offert: 'no'
  },
  {
    id: '007',
    brand: 'Nike',
    model: 'Dunk Low',
    price: '100.00€',
    color: 'Green',
    gender: 'man',
    image: 'assets/nk-dunklow.png',
    offert: 'no'
  },
  {
    id: '008',
    brand: 'Adidas',
    model: 'Gazelle',
    price: '90.00€',
    color: 'Pink',
    gender: 'man',
    image: 'assets/ad-gazelle.png',
    offert: 'no'
  },
  {
    id: '009',
    brand: 'Nike',
    model: 'Air Max SC',
    price: '150.00€',
    color: 'Brown',
    gender: 'man',
    image: 'assets/nk-aixmaxsc.png',
    offert: 'no'
  },
  {
    id: '010',
    brand: 'Adidas',
    model: 'Handball Spezial',
    price: '120.00€',
    color: 'Black',
    gender: 'man',
    image: 'assets/ad-handballspezialblack.png',
    offert: 'no'
  },
  {
    id: '011',
    brand: 'Nike',
    model: 'Air Force',
    price: '130.00€',
    color: 'Orange',
    gender: 'man',
    image: 'assets/nk-airforce.png',
    offert: 'no'
  },
  {
    id: '012',
    brand: 'New Balance',
    model: '9060',
    price: '100.00€',
    color: 'Brown',
    gender: 'man',
    image: 'assets/nb-9060brown.png',
    offert: 'no'
  },
  {
    id: '013',
    brand: 'New Balance',
    model: '480',
    price: '150.00€',
    color: 'Orange',
    gender: 'man',
    image: 'assets/nb-480.png',
    offert: 'no'
  },
  {
    id: '014',
    brand: 'Nike',
    model: 'Full Force Low',
    price: '70.00€',
    color: 'White',
    gender: 'man',
    image: 'assets/nk-fullforcelow.png',
    offert: 'no'
  },
  {
    id: '015',
    brand: 'Nike',
    model: 'Air Max SC',
    price: '160.00€',
    color: 'Grey',
    gender: 'man',
    image: 'assets/nk-aismaxsc.png',
    offert: 'no'
  },
  {
    id: '016',
    brand: 'Adidas',
    model: 'Handball Spezial',
    price: '140.00€',
    color: 'White',
    gender: 'man',
    image: 'assets/ad-handballspezialwhite.png',
    offert: 'no'
  }
];
const categoriesArrray = ['Hombre', 'Mujer', 'Niños', 'Ofertas'];
const iconsArray = [
  { icontype: 'filter', image: 'assets/icon-filter.svg' },
  { icontype: 'cart', image: 'assets/icon-cart.svg' },
  { icontype: 'profile', image: 'assets/icon-profile.svg' }
];
const sneakersArrayFilter = [
  'Todas las marcas',
  'Nike',
  'Adidas',
  'New Balance'
];
const pricesArrayFilter = [
  'Todos los precios',
  '80.00€',
  '90.00€',
  '100.00€',
  '110.00€', // incluido para hacer saltar los productos sugeridos
  '120.00€',
  '130.00€',
  '140.00€',
  '150.00€',
  '160.00€'
];
//!- HEADER -------------------------------------------------
// Insert HTML elements
let header = document.createElement('header');
let logo = document.createElement('img');
let menuBurguer = document.createElement('img');
let menu = document.createElement('ul');
let iconsDiv = document.createElement('div');
// Insert content to elements
logo.src = './assets/jd-logo.png';
logo.alt = 'logo';
menuBurguer.src = './assets/menu-burguer.png';
let menuCategories = () => {
  categoriesArrray.forEach((category) => {
    let option = document.createElement('li');
    option.textContent = category;
    menu.append(option);
  });
};
let menuIcons = () => {
  iconsArray.forEach((element) => {
    let icon = document.createElement('img');
    icon.src = element.image;
    icon.alt = element.icontype;
    iconsDiv.append(icon);
  });
};
menuCategories();
menuIcons();
// Layout with elements
document.body.append(header);
header.append(logo);
header.append(menuBurguer);
header.append(menu);
header.append(iconsDiv);
// Add CSS class
header.className = 'header';
menu.className = 'nav-menu';
iconsDiv.className = 'icons-div'; //? Falta añadir el hover en los iconos para que cambien de color
menuBurguer.className = 'burguer-menu';
//!- SECTION - FILTERS ------------------------------------
// Insert HTML elements
let filtersSection = document.createElement('section');
let filtersHeader = document.createElement('div');
let filtersImg = document.createElement('img');
let filterDisplay = document.createElement('div');
let filterDisplayButton = document.createElement('img');
let filtersSelector = document.createElement('div');
let filterBrandButton = document.createElement('select');
let filterPriceButton = document.createElement('select');
let filterApplyButton = document.createElement('button');
let filterClearButton = document.createElement('button');
// Insert content to element
sneakersArrayFilter.forEach((element) => {
  let option = document.createElement('option');
  option.value = element;
  option.textContent = element;
  filterBrandButton.append(option);
});
pricesArrayFilter.forEach((element) => {
  let option = document.createElement('option');
  option.value = element;
  option.textContent = element;
  filterPriceButton.append(option);
});
filtersImg.src = './assets/cover.png';
filtersImg.alt = 'header image';
filterApplyButton.textContent = 'Filtrar';
filterClearButton.textContent = 'Limpiar';
filterDisplayButton.src = './assets/icon-arrow.png';
filterDisplayButton.alt = 'button display filters';
filterDisplay.append(filterDisplayButton);
// Layout with elements
filtersHeader.append(filtersImg);
filtersSelector.append(
  filterBrandButton,
  filterPriceButton,
  filterClearButton,
  filterApplyButton
);
filtersSection.append(filtersHeader, filtersSelector, filterDisplay);
document.body.append(filtersSection);
// Add CSS class
filtersSection.className = 'filters-section';
filtersSelector.className = 'filters-selector hidden';
filtersHeader.className = 'filters-header';
filterDisplayButton.className = 'filter-display-button';
filterDisplay.className = 'filter-display';
filterApplyButton.className = 'filter-button';
filterClearButton.className = 'filter-button';
filterBrandButton.className = 'filter-option';
filterPriceButton.className = 'filter-option';
// Show / Hide Filters Section
filterDisplayButton.addEventListener('click', () => {
  isHidden = filtersSelector.classList.contains('hidden');
  filtersSelector.classList.toggle('hidden');
  if (isHidden) {
    filtersSelector.classList.remove('hidden');
    filtersSelector.classList.add('visible');
    filterDisplayButton.style.transform = 'rotate(180deg)';
  } else {
    filtersSelector.classList.remove('visible');
    filtersSelector.classList.add('hidden');
    filterDisplayButton.style.transform = 'rotate(0deg)';
  }
});
// "Limpiar" Button
const clearFilters = filterClearButton.addEventListener('click', () => {
  filterBrandButton.value = 'Todas las marcas';
  filterPriceButton.value = 'Todos los precios';
  printAllCards();
});
// "Filtrar" Button
const randomSneakers = () => {
  const mixSneakers = [...sneakersArray].sort(() => 0.5 - Math.random());
  const randomSelection = mixSneakers.slice(0, 3);
  const textMessage = document.createElement('p');
  textMessage.textContent =
    'No hay coincidencias con tu selección. Te mostramos otros productos que pueden interesarte.';
  textMessage.classList = 'text-message';
  sneakersSection.append(textMessage);
  randomSelection.forEach((sneaker) => createSneakerCard(sneaker));
};

const applyFilters = filterApplyButton.addEventListener('click', () => {
  const selectedPrice = filterPriceButton.value;
  const selectedBrand = filterBrandButton.value;
  let filteredSneakers = sneakersArray.filter((sneaker) => {
    const priceMatch =
      selectedPrice === 'Todos los precios' || sneaker.price === selectedPrice;
    const brandMatch =
      selectedBrand === 'Todas las marcas' || sneaker.brand === selectedBrand;
    return priceMatch && brandMatch;
  });
  sneakersSection.innerHTML = '';
  if (filteredSneakers.length > 0) {
    filteredSneakers.forEach((sneaker) => createSneakerCard(sneaker));
  } else {
    randomSneakers();
  }
});

//!- SECTION - SNEAKERS ------------------------------------
let sneakersSection = document.createElement('section');
document.body.append(sneakersSection);
sneakersSection.className = 'sneakers-section';
function createSneakerCard(sneaker) {
  // Insert HTML elements
  let cardDiv = document.createElement('div');
  let sneakerImg = document.createElement('img');
  let brandDiv = document.createElement('div');
  let sneakersInfo = document.createElement('div');
  let sneakersModel = document.createElement('p');
  let sneakersPrice = document.createElement('p');
  let buyButton = document.createElement('button');
  // Insert content to element
  sneakerImg.src = sneaker.image;
  sneakerImg.alt = sneaker.brand + sneaker.model;
  brandDiv.textContent = sneaker.brand;
  sneakersModel.textContent = sneaker.model;
  sneakersPrice.textContent = sneaker.price;
  buyButton.textContent = 'Comprar';
  // Layout with elements
  sneakersInfo.append(sneakersModel, sneakersPrice);
  cardDiv.append(sneakerImg, brandDiv, sneakersInfo, buyButton);
  sneakersSection.append(cardDiv);
  // Add CSS class
  cardDiv.className = 'card-div';
  sneakerImg.className = 'sneaker-img';
  brandDiv.className = 'brand-div ';
  sneakersModel.className = 'sneaker-model';
  sneakersPrice.className = 'sneaker-price';
  buyButton.className = 'buy-button';
  sneakersInfo.className = 'model-price';
}
function printAllCards() {
  sneakersSection.innerHTML = '';
  sneakersArray.forEach((sneaker) => {
    createSneakerCard(sneaker);
  });
}
printAllCards();
//!- FOOTER -------------------------------------------------
const footerContent = [
  {
    title: 'Compra con JD',
    options: [
      'Guia de tallas',
      'Buscador de tallas',
      'Descuento estudiantes',
      'Calendario lanzamientos',
      'Incribite a JDX',
      'JD Blog'
    ]
  },
  {
    title: 'Atención al cliente',
    options: [
      'Preguntas frecuentes',
      'Envíos y devoluciones',
      'Seguimiento de envío',
      'Contacto'
    ]
  },
  {
    title: 'Aviso legal',
    options: [
      'Términos y condiciones',
      'Promociones y condiciones',
      'Política de privacidad',
      'Política de Cookies',
      'Ajustes de Cookies',
      'Accesibilidad'
    ]
  }
];
let footerDiv = document.createElement('footer');
footerDiv.className = 'footer-div';
// para cada objeto del array creamos un ul y dentro del mismo insertamos un p con la clave title del array
footerContent.forEach((listOfElements) => {
  let footerList = document.createElement('ul');
  let elementList = document.createElement('p');
  elementList.textContent = listOfElements.title;
  footerList.append(elementList);
  footerDiv.append(footerList);
  // para cada valor de la clave options creamos un li, y le insertamos el contenido dentro
  for (let element of listOfElements.options) {
    let footerElement = document.createElement('li');
    footerElement.textContent = element;
    footerList.append(footerElement);
  }
  // insertamos los ul dentro del footer
  footerDiv.append(footerList);
});
// insertamos el footer en el body
document.body.append(footerDiv);
